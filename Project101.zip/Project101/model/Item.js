const mongoose = require('mongoose');


const itemSchema = new mongoose.Schema({
    productId: {
        type: String,
        required: true,
        min: 6,
        max: 255
    },
    productName: {
        type: String,
        required: true,
        max: 255,
        min: 6
    },
    quantity:{
        type: Number,
        required: true
    },
    price: {
        type: Number,
        required: true
    },
    cartId:{
        type: String,
        required: true,
        min: 6,
        max: 255
    },
    lastUpdate: {
        type: Date,
        default: Date.now
    }
});

module.exports = mongoose.model('Item', itemSchema);