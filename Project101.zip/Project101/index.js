const express = require('express');
const app = express();
const dotenv = require('dotenv')
const mongoose = require('mongoose');
const cors = require('cors');

//Import Routes
const authRoute = require('./routes/UserRoute/userAuth');
const productRoute = require('./routes/ProductRoute/products');
const cartRoute = require('./routes/CartRoute/cart');
// const cartRoute = require('./routes/CartRoute/cartItems');


// const postRoute = require('./routes/posts');


dotenv.config();

//Connect to DB
mongoose.connect(process.env.DB_CONNECT,
    { useNewUrlParser: true, useUnifiedTopology: true },
    () => console.log('Connect to Db!')
);

// CORS setup for Header
const corsConfig = {
    origin: true,
    credentials: true,
    exposedHeaders: [
        'auth-token',
        'Access-Control-Allow-Origin',
        'Content-Type',
        'Content-Length'
    ]

}
//Middleware
app.use(express.json());

//Route Middlewares
app.use(cors(corsConfig));
app.use('/user', authRoute);
app.use('/product', productRoute);
app.use('/cart', cartRoute);

app.use((req, res, next) => {
    res.status(404).send(`URI doesn't exist!`);
});
// app.use('/api/posts', postRoute);

app.listen(8080, () => console.log('Server Up and running'));