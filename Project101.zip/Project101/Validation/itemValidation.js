//Validation
const Joi = require('@hapi/joi');


//Register Validation
const itemValidation = data => {
    const schema = Joi.object({
        productId: Joi.string()
                .min(6)
                .required(),
        quantity: Joi.number()
                .integer()
                .min(1)
                .max(100000)
                .required()
    });

   return schema.validate(data);
};

const updateItemValidation = data => {
        const schema = Joi.object({
                quantity: Joi.number()
                        .integer()
                        .min(1)
        });
        return schema.validate(data);
};

module.exports.itemValidation = itemValidation;
module.exports.updateItemValidation = updateItemValidation;