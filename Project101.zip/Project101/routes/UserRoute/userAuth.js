const router = require('express').Router();
const User = require('../../model/User');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const Cart = require('../../model/Cart');
const { registerValidation, loginValidation } = require('../../Validation/userValidation');

//User registration
router.post('/register', async (req, res) => {

    //Response Message configuration
    const responseMessage = {
        success: false,
        responseMessage: "Account Registration was successful"
    }

    //Lets validate the data before we make a user
    const validation = registerValidation(req.body);

    if ('error' in validation) {
        const { error } = registerValidation(req.body);
        responseMessage.responseMessage = error.details[0].message;
        return res.status(400).send(responseMessage);
    }

    //Checking if the user is already in the database
    const emailExist = await User.findOne({ email: req.body.email });
    if (emailExist) {
        responseMessage.responseMessage = 'Email address already exists';
        return res.status(400).send(responseMessage);
    }
    //Hash passwords
    const salt = await bcrypt.genSalt(10);
    const hashPassword = await bcrypt.hash(req.body.password, salt);

    //Create a new user
    const user = new User({
        name: req.body.name,
        email: req.body.email,
        password: hashPassword,
        account: 'user'
    });
    let error = null;
    try {
        const savedUser = await user.save();
        const createdUser = await User.findOne({ email: req.body.email });
        // Create new Instance for Cart
        // After the user registered the system will automatically create a designated cart for them
        const cart = new Cart({
            customerId: createdUser._id,
            totalPrice: 0
        });
        const savedCart = await cart.save();
    } catch (err) {
        error = err;
    } finally {
        //Fetch the data from the document User
        const getDataOfTheUser = await User.findOne({ email: req.body.email });

        //Validating if the cart was successfully created
        const createdCart = await Cart.findOne({ customerId: getDataOfTheUser._id });

        //If the cart was not successfully created, the user details will be deleted from the document User
        if (!createdCart) {
            User.findByIdAndDelete(getDataOfTheUser._id)
                .then(() => console.log("Account Deleted"))
                .catch(err => { console.log(err) });
        }
        if (error !== null) {
            responseMessage.responseMessage = `There's something wrong`
            return res.status(400).send(responseMessage);
        }
        responseMessage.success = true;
        return res.send(responseMessage);
    }
});

//User Login
router.post('/login', async (req, res) => {

    //Lets validate the data before we make a user
    const validation = loginValidation(req.body);
    const responseMessage = {
        success: false,
        responseMessage: "Login successful",
        data: {}
    }

    if ('error' in validation) {
        const { error } = loginValidation(req.body);
        responseMessage.responseMessage = error.details[0].message
        return res.status(400).send(responseMessage);
    }

    //Checking if the email exists
    const user = await User.findOne({ email: req.body.email });
    if (!user) {
        responseMessage.responseMessage = `Email or password is wrong`
        return res.status(400).send(responseMessage);
    }
    //Password is correct
    const validPass = await bcrypt.compare(req.body.password, user.password);
    if (!validPass) {
        responseMessage.responseMessage = `Email or password is wrong`
        return res.status(400).send(responseMessage);
    }
    //Create and assign a token
    const token = jwt.sign({ _id: user._id }, process.env.TOKEN_SECRET, { expiresIn: '3h' });
    responseMessage.success = true;
    res.setHeader('auth-token', token)
    // console.log(user);
    let tempData = {
        name: user.name,
        email: user.email,
        account: user.account
    };
    responseMessage.data = tempData;
    res.send(responseMessage);
    // res.send('Login successfully');
});

module.exports = router;