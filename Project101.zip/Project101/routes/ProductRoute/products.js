const router = require('express').Router();
const Product = require('../../model/Product');
const User = require ('../../model/User');
const verify = require ('../verifyToken');
// const jwt = require('jsonwebtoken');
// const bcrypt = require('bcryptjs');
const {productValidation} = require('../../Validation/productValidation');

/* Products Route */

//Read all available products from the DB
router.get("/", async (req, res) => {
    Product.find()
        .then(products => res.json(products))
        .catch(err => res.status(400).json('Error: ' + err));
});

//Fetch the product using the id
router.get("/:id", async (req, res) => {
    const productExist = await Product.findById(req.params.id);
    if(productExist === null) return res.status(400).send(`Product doesn't exist`);

    return res.status(200).send(productExist);
});

//Create (Add) product to the DB
router.post("/", verify, async (req, res) => {

    //User validation
    //Admin account is the only one who can add product
    const userId = req.user._id;
    let userAccount;
    try{
        const userDetail = await User.findOne({ _id :userId});
        userAccount = userDetail.account;
    }catch (error){
        console.log(error);
    }

    if(userAccount !== 'admin'){
        return res.status(400).send({status: false, responseMessage: 'Invalid user account'});
    }
   
    //Product Input Validation
    const validation = productValidation(req.body);
    if('error' in validation){
        const {error} = productValidation(req.body);
        return res.status(400).send(error.details[0].message);
    }

    //Validation if the product already exist
    const productExist = await Product.findOne({product: req.body.product});
    if(productExist) return res.status(400).send('Product already exists');

    //Create a new product 
    const product = new Product({
        product: req.body.product,
        category: req.body.category,
        description: req.body.description,
        quantity: req.body.quantity,
        price: req.body.price
    });
    try{
        const savedProduct = await product.save();
        res.send({productId: savedProduct._id});
    }catch(err){
        res.status(400).send(err);
    }
});

//Update the product using product id
router.put("/:id", async (req, res) => {
    const productExist = await Product.findById(req.params.id);
    if(productExist === null) return res.status(400).send(`Product doesn't exist`);
    
    Product.findByIdAndUpdate(req.params.id)
        .then(product => {
            product.product = req.body.product,
            product.category = req.body.category,
            product.description = req.body.description,
            product.quantity = req.body.quantity,
            product.price = req.body.price

            product.save()
                .then(() => res.json({message: "Product updated successfully", product}))
                .catch(err => res.status(400).json('Error: '  + err));
        })
        .catch(err => res.status(400).json('Error: '  + err));
});

//Delete product from DB using product id
router.delete("/:id", async (req, res) => {

    const productExist = await Product.findById(req.params.id);
    if(productExist === null) return res.status(400).send(`Product doesn't exist`);

    Product.findByIdAndDelete(req.params.id)
        .then(() => res.json('Product successfully deleted. '))
        .catch(err => res.status(400).json('Error: ' + err));
});


module.exports = router;