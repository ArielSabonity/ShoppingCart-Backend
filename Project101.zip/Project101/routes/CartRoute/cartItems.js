const router = require('express').Router();
const Item = require('../../model/Item');
const Product = require ('../../model/Product');
const {itemValidation, updateItemValidation} = require('../../Validation/itemValidation');

//Fetch all item
router.get("/", async (req, res) => {
    
    Item.find()
        .then(item => res.json(item))
        .catch(err => res.status(400).json('Error: ' + err));
});

//Fetch item using id
router.get("/:id", async (req, res) => {
    const itemExist = await Item.findById(req.params.id);
    if(itemExist === null) return res.status(400).send(`Item doesn't exist`);

    return res.status(200).send(itemExist);
});


//Add item to the Cart Array
router.post("/", async (req, res) => {
    
    const validation = validationForItem(req.body);

    //Validate if the product is available using the given productId
    const productExist = await Product.findOne({_id: req.body.productId});
    if (!productExist) return res.status(400).send("Product is not available");
    
    if(req.body.quantity <= 0) return res.status(400).send("The quantity should be greater than or equal to 1");

    //Validate if the product have enought stock 
    if(req.body.quantity > productExist.quantity) return res.status(400).send("Doesn't have enough stock");

    //Price computation
    const computedPrice = priceComputation({quantity: req.body.quantity, price: productExist.price});
    
    const item = new Item({
        productId: productExist._id,
        productName: productExist.product,
        quantity: req.body.quantity,
        price: computedPrice,
        cartId: req.body.cartId
    });

    try{
        const savedItem = await item.save();
        await updateProductInventory({productId: productExist._id, quantity: req.body.quantity});
        res.send(savedItem);
    }catch(err){
        res.status(400).send(err);
    }
});


//Delete the item from the DB
router.delete('/:id', async (req, res) => {
    const itemExist = await Item.findById(req.params.id);
    if(itemExist === null) return res.status(400).send(`Item doesn't exist`);

    Item.findByIdAndDelete(req.params.id)
        .then(() => console.log('Item deleted successfully. '))
        .catch(err => console.log('Error: ' + err));

    try{
        updateProductInventory({productId: itemExist.productId, quantity: -itemExist.quantity});
        return res.json('Product successfully deleted. ');
    } catch (err) {
        console.log(err);
    }
});

//Update the item from the DB
router.put('/:id', async (req, res) => {
    const itemExist = await Item.findById(req.params.id);
    if(itemExist === null) return res.status(400).send(`Item doesn't exist`);
    // console.log("He")
    //Validate input, quantity is the only allowed input
    const validation = updateItemValidation(req.body);
    if('error' in validation){
        const {error} = updateItemValidation(req.body);
        return res.status(400).send(error.details[0].message);
    }
    //Validation if the item quantity should subtract or add from the product inventory
    let difference;
    const productExist = await Product.findById(itemExist.productId);
    if(req.body.quantity > itemExist.quantity){
        difference = itemExist .quantity - req.body.quantity;
        
        if(-difference > productExist.quantity) return res.status(400).send("Doesn't have enough stock");
    } else{
        difference = itemExist.quantity - req.body.quantity;
    }
  
    //New price computation
    const computedPrice = priceComputation({quantity: req.body.quantity, price: productExist.price});
    console.log
    Product.findByIdAndUpdate(itemExist.productId)
    .then(product => {
        product.product = product.product,
        product.category = product.category,
        product.description = product.description,
        product.quantity = product.quantity + difference,
        product.price = product.price
        console.log(product.quantity + "   " + difference);
        product.save()
            .then(() => console.log({message: "Product update successfully"}))
            .catch(err => console.log('Error: '  + err + "/n " +  product.quantity));
    })
    .catch(err => console.log('Error: '  + err));

    Item.findByIdAndUpdate(req.params.id)
    .then(item => {
        item.productId = item.productId,
        item.productName = item.productName,
        item.quantity = req.body.quantity,
        item.price = computedPrice,
        item.cartId = item.cartId
        item.save()
            .then(() => console.log({message: "Item updated successfully"}))
            .catch(err => console.log('Error3: '  + err));
    })
    .catch(err => console.log('Error4: '  + err));

    try{
        updateProductInventory({productId: itemExist.productId, quantity: -difference});
    }catch (err) {
        console.log(err);
    }
     return res.json('Item successfully update');
});

const validationForItem = param => {
    const validation = itemValidation(param);
   
    if('error' in validation){
        const {error} = itemValidation(param);
        return res.status(400).send(error.details[0].message);
    }
}

const priceComputation = param => {
    return param.quantity * param.price;
}

const updateProductInventory = param => {
    console.log(param.productId);
    Product.findByIdAndUpdate(param.productId)
        .then(product => {
            product.product = product.product,
            product.category = product.category,
            product.description = product.description,
            product.quantity = product.quantity - param.quantity,
            product.price = product.price

            product.save()
                .then(() => console.log("Product Inventory updated successfully"))
                .catch(err => console.log("Error : " + err));
        })
        .catch(err => console.log("Error : " + err));
}


module.exports = router;