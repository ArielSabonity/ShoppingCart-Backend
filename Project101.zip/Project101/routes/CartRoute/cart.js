const router = require('express').Router();
const verify = require('../verifyToken');
const Cart = require('../../model/Cart');
const Product = require('../../model/Product');
const User = require('../../model/User');
const { itemValidation, updateItemValidation } = require('../../Validation/itemValidation');



router.get('/', verify, async (req, res) => {
    const user = req.user._id;
    const response = {
        success: false,
        responseMessage: ""
    }
    //Get the Cart of the user
    const userCart = await Cart.findOne({ customerId: user });

    if (userCart === undefined) {
        response.responseMessage = "Cart doesn't exist"
    }
    //Fetch all the items that was included in the cart
    res.json(userCart);
});

router.get('/items', async (req, res) => {
    res.json({ message: "Hello" });
})

//Add item to the Cart
router.post('/items', verify, async (req, res) => {
    let responseMessage = ({
        success: false,
        message: "Item has been added successfully"
    })

    try {
        //Input validation
        const validation = itemValidation(req.body);
        if ('error' in validation) {
            const { error } = itemValidation(req.body);
            responseMessage.message = error.details[0].message;
            return res.status(400).send(responseMessage);
        }

        //Check if the Product exist
        const productExist = await Product.findOne({ _id: req.body.productId });
        if (!productExist) {
            responseMessage.message = `Product doesn't exist`;
            return res.status(400).send(responseMessage);
        }

        //Checking for product quantity availability
        if (productExist.quantity < req.body.quantity) {
            responseMessage.message = `Product don't have enough stock`;
            return res.status(400).send(responseMessage);
        }
        //Deducting the users item to the current stock
        await updateProductInventory({ productId: productExist._id, quantity: req.body.quantity });

        // Retrieve the  Cart of the user
        const usersCart = await getUsersCart(req.user._id);

        //Temporary configuration for object item
        let itemObject = {
            itemId: req.body.productId,
            itemName: productExist.product,
            quantity: req.body.quantity,
            price: 0
        };

        //Update the List of item inside users cart
        const updateItems = updateItemList(usersCart.item, itemObject, productExist.price);
        // console.log(updateItems);

        //Update users cart with the correct item list
        updateCartDetails(usersCart, updateItems);

        responseMessage.success = true;

        res.send(responseMessage);


    } catch (error) {
        console.log(error)
    }
});


//Delete item
router.delete('/items/:id', verify, async (req, res) => {
    let responseMessage = {
        success: "false",
        responseMessage: "Item successfully deleted"
    }
    try {
        //Get users cart
        const usersCart = await getUsersCart(req.user._id);
        let itemList = usersCart.item;
        // console.log(req.params.id);
        let itemExist = itemList.findIndex((item) => item.itemId === req.params.id);

        if (itemExist < 0) {
            responseMessage.responseMessage = `Item doesn't exist`;
            return res.status(400).send(responseMessage);
        }

        let newItemList = itemList.filter((item) => item.itemId !== req.params.id);
        // console.log(newItemList);

        //Update users cart with the correct item list
        updateCartDetails(usersCart, newItemList);
        //Update Inventort
        updateProductInventory({ productId: req.params.id, quantity: -itemList[itemExist].quantity });

        responseMessage.success = true;
        res.send(responseMessage);

    } catch (error) {
        console.log("Delete Error");
    }
});

//Update Item
router.put('/items/:id', verify, async (req, res) => {
    let responseMessage = {
        success: "false",
        responseMessage: "Item has been updated successfully"
    }
    try {
        const usersCart = await getUsersCart(req.user._id);
        let itemList = usersCart.item;
        // console.log(itemList);
        let itemExist = itemList.findIndex((item) => item.itemId === req.params.id);

        if (itemExist < 0) {
            responseMessage.responseMessage = `Item doesn't exist`;
            return res.status(400).send(responseMessage);
        }

        const productExist = await Product.findOne({ _id: req.params.id});
        if (!productExist) {
            responseMessage.responseMessage = `Product doesn't exist`;
            return res.status(400).send(responseMessage);
        }

        let difference = req.body.quantity - itemList[itemExist].quantity;
        //  console.log("Difference : " + difference + "    Quantity : " + productExist.quantity);
        if (difference > 0) {
            if (productExist.quantity < difference) {
                responseMessage.responseMessage = `Product doesn't have enough stock`;
                return res.status(400).send(responseMessage);
            } else {
                updateProductInventory({ productId: req.params.id, quantity: difference });
            }

        } else {
            difference = difference * (-1);
            updateProductInventory({ productId: req.params.id, quantity: - (difference) });
        }

        itemList.map(item => {
            if(item.itemId === req.params.id) {
                item.quantity = req.body.quantity;
                item.price = priceComputation(req.body.quantity, productExist.price);
            }
        });

        updateCartDetails(usersCart, itemList);

        responseMessage.success = true;
        res.send(responseMessage);


    } catch (error) {
        console.log(error);
    }
});



//Generic functions

//Function for Price Computation
const priceComputation = (quantity, price) => {
    return quantity * price;
}


//Get the users cart
const getUsersCart = async (userId) => {
    const userCart = await Cart.findOne({ customerId: userId });
    return userCart;
}

//Update the list of items in cart
const updateItemList = (itemList, item, productPrice) => {
    let itemExist = itemList.findIndex(tempItem => tempItem.itemId === item.itemId);

    if (itemExist < 0) {
        let price = priceComputation(item.quantity, productPrice);
        item.price = price;
        itemList.push(item);
    } else {
        tempItem = itemList[itemExist];
        tempItem.quantity += item.quantity;
        tempItem.price = priceComputation(tempItem.quantity, productPrice);
        itemList[itemExist] = tempItem;
    }

    return itemList;
}

//Function for updating the product quantity in inventory
const updateProductInventory = param => {
    // console.log(param.productId);
    Product.findByIdAndUpdate(param.productId)
        .then(product => {
            product.product = product.product,
                product.category = product.category,
                product.description = product.description,
                product.quantity = product.quantity - param.quantity,
                product.price = product.price

            product.save()
                .then(() => console.log("Product Inventory updated successfully"))
                .catch(err => console.log("Error : " + err));
        })
        .catch(err => console.log("Error : " + err));
}

const updateCartDetails = (param, itemList) => {

    let totalPrice = 0;
    itemList.map((item) => {
        totalPrice += item.price
    });
    Cart.findByIdAndUpdate(param._id)
        .then(cart => {
            cart.item = itemList,
                cart.totalPrice = totalPrice,
                cart.customerId = param.customerId

            cart.save()
                .then(() => console.log("Cart updated successfully"))
                .catch((err) => console.log("Updating cart Error: " + err))
        })
}

module.exports = router;


